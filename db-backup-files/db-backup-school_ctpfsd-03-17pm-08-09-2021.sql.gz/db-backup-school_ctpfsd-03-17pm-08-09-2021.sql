CREATE DATABASE IF NOT EXISTS `school_ctpfsd`;

USE `school_ctpfsd`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `admissions`;

CREATE TABLE `admissions` (
  `idadmission` int(200) NOT NULL AUTO_INCREMENT,
  `idstudent` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `totalfee` int(200) NOT NULL,
  `paidfee` int(200) NOT NULL,
  `pendingdues` int(200) NOT NULL,
  `admissiondate` date NOT NULL DEFAULT current_timestamp(),
  `discount` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `registration` varchar(200) NOT NULL,
  `admissionbyuserid` int(20) NOT NULL,
  `entrydate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idadmission`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `courses`;

CREATE TABLE `courses` (
  `idcourses` int(200) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(200) NOT NULL,
  `fee` int(200) NOT NULL,
  PRIMARY KEY (`idcourses`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `courses` VALUES (1,"Bike2Weeks",1600),
(2,"Car2Weeks",3200),
(3,"Car4Weeks",6400);


DROP TABLE IF EXISTS `expense`;

CREATE TABLE `expense` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `idexpenses` int(200) NOT NULL AUTO_INCREMENT,
  `idexpensetype` int(200) NOT NULL,
  `amount` int(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idusers` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idexpenses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `expensetypes`;

CREATE TABLE `expensetypes` (
  `idexpensetypes` int(200) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`idexpensetypes`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `expensetypes` VALUES (1,"Petrol"),
(2,"Maintenance"),
(3,"Salary"),
(4,"Rent"),
(5,"Miscellaneous"),
(6,"Welfare");


DROP TABLE IF EXISTS `income`;

CREATE TABLE `income` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `schools`;

CREATE TABLE `schools` (
  `idschools` int(200) NOT NULL AUTO_INCREMENT,
  `location` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `schoolcode` varchar(200) NOT NULL,
  PRIMARY KEY (`idschools`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `schools` VALUES (1,"CTPF","FSD","CTPF"),
(2,"People Colony","FSD","PC"),
(3,"Samundri","FSD","SMND"),
(4,"Jaranwala","FSD","JRNW"),
(5,"Dijkot","FSD","DJKT"),
(6,"Jhumra","FSD","JMRA"),
(10,"GM Abad","FSD","GMABD");


DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `idstaff` int(200) NOT NULL AUTO_INCREMENT,
  `idschool` int(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `belt` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `idtypestaff` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idstaff`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `staff` VALUES (1,1,"Ali","Nizami","Admin",1,3216611821,1,"2021-07-17"),
(2,2,"Imran","Qazi","TW",780,"",10,"2021-07-17"),
(3,10,"Sohail","Ahmad","TW",555,"",2,"2021-09-08");


DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `idstudents` int(200) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) NOT NULL,
  `fathername` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `cnic` varchar(200) NOT NULL,
  `address` varchar(300) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `blood` varchar(200) NOT NULL,
  `idadmission` int(200) NOT NULL,
  PRIMARY KEY (`idstudents`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `typestaff`;

CREATE TABLE `typestaff` (
  `idtypestaff` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idtypestaff`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `typestaff` VALUES (1,"ADMIN"),
(2,"Data Entry Operator"),
(3,"Mali"),
(4,"Naib Qasid"),
(5,"Instructor"),
(6,"Instructor PVT"),
(7,"Lady Instructor"),
(8,"Lady Instructor PVT"),
(9,"Machanic"),
(10,"Incharge");


DROP TABLE IF EXISTS `userlog`;

CREATE TABLE `userlog` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `idusers` int(200) NOT NULL,
  `session` varchar(200) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `action` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;

INSERT INTO `userlog` VALUES (1,2,4,"2021-07-17 14:54:39","login"),
(2,2,4,"2021-07-17 15:03:03","login"),
(3,2,4,"2021-07-17 15:09:53","login"),
(4,100,"\".session_id().\"","2021-07-17 15:18:18","login"),
(5,100,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:19:27","login"),
(6,100,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:26:13","logout"),
(7,100,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:26:27","login"),
(8,100,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:26:54","logout"),
(9,100,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:27:11","login"),
(10,100,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:35:05","logout"),
(11,118,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:35:35","login"),
(12,118,"tbis172ie4msq3ucrj90odr0cb","2021-07-17 15:36:52","logout"),
(13,100,"t5lsu9guivon12m655j8pqcbo7","2021-07-19 11:01:27","login"),
(14,100,"lrcmahhjp9djpfjk5d485q60v6","2021-07-23 12:08:56","login"),
(15,100,"v0lop6bdknf8j1d43o77s2idcp","2021-07-24 10:48:59","login"),
(16,100,"v0lop6bdknf8j1d43o77s2idcp","2021-07-24 10:57:55","logout"),
(17,100,"v0lop6bdknf8j1d43o77s2idcp","2021-07-24 10:58:10","login"),
(18,100,"v0lop6bdknf8j1d43o77s2idcp","2021-07-24 10:59:17","logout"),
(19,100,"v0lop6bdknf8j1d43o77s2idcp","2021-07-24 10:59:23","login"),
(20,100,"vsg3jak4fguikrcfkop2n5ufj6","2021-09-08 10:40:25","login"),
(21,100,"vsg3jak4fguikrcfkop2n5ufj6","2021-09-08 13:38:03","logout"),
(22,118,"vsg3jak4fguikrcfkop2n5ufj6","2021-09-08 13:38:24","login"),
(23,100,"q9n87es8ef2rmenl8bl0d9st8i","2021-09-08 15:13:19","login"),
(24,100,"q9n87es8ef2rmenl8bl0d9st8i","2021-09-08 15:15:45","logout"),
(25,119,"q9n87es8ef2rmenl8bl0d9st8i","2021-09-08 15:15:53","login");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `idusers` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `creationdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `idusertype` int(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idstaff` int(200) NOT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` VALUES (100,"admin","admin","2021-02-15 11:27:09",1,"active",1,1),
(118,"PCTW780","JSQcHnp","2021-07-17 15:34:50",2,"active",2,2),
(119,"GMABD_3_2","ctpfsd","2021-09-08 15:14:42",2,"active",10,3);


DROP TABLE IF EXISTS `usershistory`;

CREATE TABLE `usershistory` (
  `idusershistory` int(200) NOT NULL AUTO_INCREMENT,
  `idusers` int(200) NOT NULL,
  `activation` date NOT NULL,
  `deactivation` date NOT NULL,
  `lastlogin` date NOT NULL,
  PRIMARY KEY (`idusershistory`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usershistory` VALUES (1,2,"2021-02-15","0000-00-00","2021-02-15");


DROP TABLE IF EXISTS `usertypes`;

CREATE TABLE `usertypes` (
  `idusertypes` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idusertypes`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usertypes` VALUES (1,"Admin"),
(2,"Incharge"),
(3,"Deo");


SET foreign_key_checks = 1;
