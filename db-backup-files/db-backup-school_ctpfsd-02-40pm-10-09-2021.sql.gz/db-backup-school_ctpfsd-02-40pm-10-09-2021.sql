CREATE DATABASE IF NOT EXISTS `school_ctpfsd`;

USE `school_ctpfsd`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `admissions`;

CREATE TABLE `admissions` (
  `idadmission` int(200) NOT NULL AUTO_INCREMENT,
  `idstudent` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `totalfee` int(200) NOT NULL,
  `paidfee` int(200) NOT NULL,
  `pendingdues` int(200) NOT NULL,
  `admissiondate` date NOT NULL DEFAULT current_timestamp(),
  `discount` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `registration` varchar(200) NOT NULL,
  `admissionbyuserid` int(20) NOT NULL,
  `entrydate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idadmission`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admissions` VALUES (1,1,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF21",122,"2021-09-10 12:58:16"),
(2,2,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF22",122,"2021-09-10 13:00:56"),
(3,3,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF23",122,"2021-09-10 13:03:17"),
(4,4,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF24",122,"2021-09-10 13:07:43"),
(5,5,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF25",122,"2021-09-10 13:11:38"),
(6,6,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF26",122,"2021-09-10 13:15:12"),
(7,7,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF27",122,"2021-09-10 13:17:52"),
(8,8,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF28",122,"2021-09-10 13:19:56"),
(9,9,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF29",122,"2021-09-10 13:21:34"),
(10,10,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF210",122,"2021-09-10 13:25:50"),
(11,11,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF211",122,"2021-09-10 13:28:06"),
(12,12,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF212",122,"2021-09-10 13:30:07"),
(13,13,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF213",122,"2021-09-10 13:32:52"),
(14,14,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF214",122,"2021-09-10 13:36:07"),
(15,15,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF215",122,"2021-09-10 13:38:50"),
(16,16,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF216",122,"2021-09-10 13:42:21"),
(17,17,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF217",122,"2021-09-10 13:44:18"),
(18,18,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF218",122,"2021-09-10 13:46:50"),
(19,19,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF219",122,"2021-09-10 13:48:46"),
(20,20,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF220",122,"2021-09-10 13:52:35"),
(21,21,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF221",122,"2021-09-10 14:03:34"),
(22,22,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF222",122,"2021-09-10 14:04:53"),
(23,23,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF223",122,"2021-09-10 14:05:53"),
(24,24,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF224",122,"2021-09-10 14:07:15"),
(25,25,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF225",122,"2021-09-10 14:08:30"),
(26,26,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF226",122,"2021-09-10 14:09:42"),
(27,27,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF227",122,"2021-09-10 14:10:49"),
(28,28,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF228",122,"2021-09-10 14:12:06"),
(29,29,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF229",122,"2021-09-10 14:13:13"),
(30,30,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF230",122,"2021-09-10 14:14:31"),
(31,31,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF231",122,"2021-09-10 14:15:39"),
(32,32,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF232",122,"2021-09-10 14:16:45"),
(33,33,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF233",122,"2021-09-10 14:18:05"),
(34,34,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF234",122,"2021-09-10 14:19:09"),
(35,35,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF235",122,"2021-09-10 14:20:29"),
(36,36,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF236",122,"2021-09-10 14:22:07"),
(37,37,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF237",122,"2021-09-10 14:23:41"),
(38,38,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF238",122,"2021-09-10 14:24:49"),
(39,39,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF239",122,"2021-09-10 14:26:07"),
(40,40,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF240",122,"2021-09-10 14:27:11"),
(41,41,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF241",122,"2021-09-10 14:28:08"),
(42,42,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF242",122,"2021-09-10 14:29:21"),
(43,43,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF243",122,"2021-09-10 14:30:45"),
(44,44,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF244",122,"2021-09-10 14:32:10"),
(45,45,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF245",122,"2021-09-10 14:33:32"),
(46,46,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF246",122,"2021-09-10 14:34:39"),
(47,47,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF247",122,"2021-09-10 14:35:59"),
(48,48,2,"2021-09-10","2021-09-10","",3200,3200,0,"2021-09-10",0,0,2,"2021CTPF248",122,"2021-09-10 14:37:16");


DROP TABLE IF EXISTS `courses`;

CREATE TABLE `courses` (
  `idcourses` int(200) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(200) NOT NULL,
  `fee` int(200) NOT NULL,
  PRIMARY KEY (`idcourses`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `courses` VALUES (1,"Bike2Weeks",1600),
(2,"Car2Weeks",3200),
(3,"Car4Weeks",6400);


DROP TABLE IF EXISTS `expense`;

CREATE TABLE `expense` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `idexpenses` int(200) NOT NULL AUTO_INCREMENT,
  `idexpensetype` int(200) NOT NULL,
  `amount` int(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idusers` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idexpenses`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `expensetypes`;

CREATE TABLE `expensetypes` (
  `idexpensetypes` int(200) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`idexpensetypes`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `expensetypes` VALUES (1,"Petrol"),
(2,"Maintenance"),
(3,"Salary"),
(4,"Rent"),
(5,"Miscellaneous"),
(6,"Welfare");


DROP TABLE IF EXISTS `income`;

CREATE TABLE `income` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `schools`;

CREATE TABLE `schools` (
  `idschools` int(200) NOT NULL AUTO_INCREMENT,
  `location` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `schoolcode` varchar(200) NOT NULL,
  PRIMARY KEY (`idschools`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `schools` VALUES (1,"CTPF","FSD","CTPF"),
(2,"People Colony","FSD","PC"),
(3,"Samundri","FSD","SMND"),
(4,"Jaranwala","FSD","JRNW"),
(5,"Dijkot","FSD","DJKT"),
(6,"Jhumra","FSD","JMRA"),
(10,"GM Abad","FSD","GMABD");


DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `idstaff` int(200) NOT NULL AUTO_INCREMENT,
  `idschool` int(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `belt` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `idtypestaff` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idstaff`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `staff` VALUES (1,1,"Ali","Nizami","Admin",1,3216611821,1,"2021-07-17"),
(6,2,"Shakeel","Anjum","TW",3270,"",2,"2021-09-09");


DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `idstudents` int(200) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) NOT NULL,
  `fathername` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `cnic` varchar(200) NOT NULL,
  `address` varchar(300) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `blood` varchar(200) NOT NULL,
  `idadmission` int(200) NOT NULL,
  PRIMARY KEY (`idstudents`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4;

INSERT INTO `students` VALUES (1,"Sajawal Ameeen","Muhammad Rafique","","male","1998-12-08",3310284957501,"fsd",03057221460,0,2,2,"0000-00-00","0000-00-00","morning","B+",1),
(2,"Muhammad Aryan","Muhammad Ashraf","","male","2003-12-02",3310207850917,"",03007669255,0,2,2,"0000-00-00","0000-00-00","morning","B+",2),
(3,"Obaid Sager","George masee","","male","1991-01-01",3310275930793,"fsd",03007655551,0,2,2,"0000-00-00","0000-00-00","morning","B+",3),
(4,"Muhammad Waqas","Muhammad Afzal","","male","2021-01-09",3330231417853,"fsd",03070617044,0,2,2,"0000-00-00","0000-00-00","morning","A+",4),
(5,"zain ul abideen","khalid","","male","1992-08-16",3310297016205,"fsd",03127667805,0,2,2,"0000-00-00","0000-00-00","morning","AB+",5),
(6,"Hania","Muhammad Sadiq","","female","2021-09-01",3330370542858,"fsd",03232449183,0,2,2,"0000-00-00","0000-00-00","morning","O+",6),
(7,"Muhammad Asad","Shafiq Ismail","","male","2003-04-09",3310207338089,"fsd",03247713123,0,2,2,"0000-00-00","0000-00-00","morning","B+",7),
(8,"Sawera Tabasum","Muhammad Kashif","","female","2000-06-09",3310181565450,"fsd",03433485083,0,2,2,"0000-00-00","0000-00-00","morning","B+",8),
(9,"Mubasher Rasheed","Rahid Ahmad","","male","1997-09-01",3310044600865,"fsd",03046424539,0,2,2,"0000-00-00","0000-00-00","morning","B+",9),
(10,"benish fatima","arfan ali","","female","1999-12-27",3310258309932,"fsd",03030477836,0,2,2,"0000-00-00","0000-00-00","morning","B+",10),
(11,"ALI RAZA","ARSHAD","","male","1993-07-17",3310216013849,"",03056351700,0,2,2,"0000-00-00","0000-00-00","morning","B+",11),
(12,"ANMR MASEEH","BAJA MASEEH","","male","1964-07-25",3310312733181,"fsd",03021688561,0,2,2,"0000-00-00","0000-00-00","morning","B+",12),
(13,"GHULAM RASOOL","Muhammad NAWZ","","male","0000-00-00",3310483539161,"fsd","",0,2,2,"0000-00-00","0000-00-00","morning","B+",13),
(14,"DURE E NAYAB","ALI BILAL","","male","1988-09-10",3310291714718,"fsd",03000453976,0,2,2,"0000-00-00","0000-00-00","morning","O+",14),
(15,"UMAIR HUSSAIN","AFZAL SHAH","","male","2003-06-28",3310077361319,"fsd",03017088204,0,2,2,"0000-00-00","0000-00-00","morning","B+",15),
(16,"MUZAMMAL HUSSAIN","Muhammad JAVED","","male","2001-12-19",3310067555623,"fsd",03076878808,0,2,2,"0000-00-00","0000-00-00","morning","A+",16),
(17,"ZAIN ALI","M JAVEED","","male","2000-07-28",3310272413861,"fsd",03037761846,0,2,2,"0000-00-00","0000-00-00","morning","A+",17),
(18,"HAMZA JAVEED","JAVEED SADIQ","","male","1994-02-12",3310001158187,"fsd",03239647182,0,2,2,"0000-00-00","0000-00-00","morning","AB+",18),
(19,"Muhammad BILAL","Muhammad RAMZAN","","male","1994-09-10",3310050983315,"fsd","",0,2,2,"0000-00-00","0000-00-00","morning","O+",19),
(20,"Muhammad BILAL","NOOR HUSSAIN","","male","1996-03-28",3310095601359,"fsd",03015772702,0,2,2,"0000-00-00","0000-00-00","morning","B+",20),
(21,"Tasneem Abu baker","Abu baker saddique","","male","1982-09-03",3310212733199,"fsd",03336568201,0,2,2,"0000-00-00","0000-00-00","morning","O+",21),
(22,"Muhammad fahad","Muhammad Nawaz","","male","2000-01-10",3310006662399,"fsd",03006068666,0,2,2,"0000-00-00","0000-00-00","morning","A+",22),
(23,"Hamza","Bao Imran","","male","2001-10-29",3310275816651,"f",03045102862,0,2,2,"0000-00-00","0000-00-00","morning","A+",23),
(24,"zamia Bashir","Muhammad Shahzad Nawaz","","male","1986-01-01",3330130285386,"fsd",03326980264,0,2,2,"0000-00-00","0000-00-00","morning","B+",24),
(25,"Danish ali","Akhter Ali","","male","1992-03-28",3310217326905,"fsd",0310710609,0,2,2,"0000-00-00","0000-00-00","morning","AB+",25),
(26,"Mishal Rasheed","Abdul Rasheed","","female","1999-02-20",3310298392834,"fsd",03137284516,0,2,2,"0000-00-00","0000-00-00","morning","O+",26),
(27,"Shahroz","Arif Bashir","","male","1998-09-15",3130141550305,"",03361667524,0,2,2,"0000-00-00","0000-00-00","morning","B+",27),
(28,"Nabeel Rehman","Abdul Sattar","","male","1997-09-04",3310237370217,"fsd",03060910131,0,2,2,"0000-00-00","0000-00-00","morning","O+",28),
(29,"Muhammad Jawad","Muhammad Akber","","male","2000-01-01",3310421135259,"fsd",03000066266,0,2,2,"0000-00-00","0000-00-00","morning","B-",29),
(30,"Umair Ali","Mubarik Ali","","male","1995-08-10",3310341193119,"fsd",03005379577,0,2,2,"0000-00-00","0000-00-00","morning","A+",30),
(31,"Qaiser Iqbal","Abdul Razzaq","","male","1981-05-10",3310090297701,"fsd",03326637876,0,2,2,"0000-00-00","0000-00-00","morning","AB+",31),
(32,"Hira Eman","Rouf Sattar","","female","2003-06-01",3310287342680,"fsd",03187966486,0,2,2,"0000-00-00","0000-00-00","morning","A+",32),
(33,"Narjish Afzal","Umar Draaz","","male","1987-10-25",3410165347478,"fsd",03336553404,0,2,2,"0000-00-00","0000-00-00","morning","B+",33),
(34,"Momin Noman","Muhammad Noman","","male","2003-06-07",3310202381483,"fsd",03009664838,0,2,2,"0000-00-00","0000-00-00","morning","O+",34),
(35,"Mehmoona idrees","Muhammad idrees","","male","1988-01-10",3310453168504,"fsd",03005468745,0,2,2,"0000-00-00","0000-00-00","morning","A+",35),
(36,"Laraib Javed","Muhammad Javed","","female","2001-06-28",331005830898,"fsd",03227540356,0,2,2,"0000-00-00","0000-00-00","morning","A+",36),
(37,"Abdul Rehman","Talib Hussain","","male","1992-06-04",3310399844113,"fsd",03061009224,0,2,2,"0000-00-00","0000-00-00","morning","A+",37),
(38,"Ehsan Kamal","Muhammad Naveed","","male","2000-09-02",3310469557825,"fsd",03067188719,0,2,2,"0000-00-00","0000-00-00","morning","A+",38),
(39,"Muhammad Saad","Muhammad Ishtiaq","","male","2003-07-11",3310083316135,"fsd",03302467676,0,2,2,"0000-00-00","0000-00-00","morning","B+",39),
(40,"Tayyba Shafiq","Muhammad Shafiq","","female","1992-03-28",3310006124988,"fsd",03079902418,0,2,2,"0000-00-00","0000-00-00","morning","A+",40),
(41,"Afaq ali","Muhammad Saeed","","male","2000-09-28",3310258464423,"fsd",03454799023,0,2,2,"0000-00-00","0000-00-00","morning","AB+",41),
(42,"Muhammad Fahad","Muhammad Umar","","male","2001-12-04",3310291261429,"fsd",03095662447,0,2,2,"0000-00-00","0000-00-00","morning","A+",42),
(43,"Muhammad Awais","Muhammad Qasim","","male","2002-12-02",3310012741053,"fsd",03042996999,0,2,2,"0000-00-00","0000-00-00","morning","B+",43),
(44,"Muhammad Tasleem","Muhammad Saddique","","male","1996-03-29",8120235352787,"fsd",03048184566,0,2,2,"0000-00-00","0000-00-00","morning","B+",44),
(45,"Muhammad Haseeb","Javed Alam","","male","2002-04-14",3310014765249,"fsd",03167025759,0,2,2,"0000-00-00","0000-00-00","morning","O+",45),
(46,"Hunain Ali","Zahoor Ahmad","","male","2001-07-13",3310386975265,"fsd",03042721260,0,2,2,"0000-00-00","0000-00-00","morning","O+",46),
(47,"Javeria Iqbal","Muhammad Iqbal","","female","2001-06-01",3310003182562,"fsd",03202261322,0,2,2,"0000-00-00","0000-00-00","morning","B+",47),
(48,"Eman Saqib","Saqib","","female","2003-08-11",3310020572320,"fsd",03007766768,0,2,2,"0000-00-00","0000-00-00","morning","O+",48);


DROP TABLE IF EXISTS `typestaff`;

CREATE TABLE `typestaff` (
  `idtypestaff` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idtypestaff`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `typestaff` VALUES (1,"ADMIN"),
(2,"Data Entry Operator"),
(3,"Mali"),
(4,"Naib Qasid"),
(5,"Instructor"),
(6,"Instructor PVT"),
(7,"Lady Instructor"),
(8,"Lady Instructor PVT"),
(9,"Machanic"),
(10,"Incharge");


DROP TABLE IF EXISTS `userlog`;

CREATE TABLE `userlog` (
  `id` int(200) NOT NULL AUTO_INCREMENT,
  `idusers` int(200) NOT NULL,
  `session` varchar(200) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  `action` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

INSERT INTO `userlog` VALUES (1,100,"ld85kjbrvku95nnkqf65jtsmgd","2021-09-09 13:02:37","logout"),
(2,120,"ltbvtpctj0qeuh3ef33ukddtat","2021-09-09 13:04:11","login"),
(3,120,"ltbvtpctj0qeuh3ef33ukddtat","2021-09-09 13:05:37","logout"),
(4,120,"ltbvtpctj0qeuh3ef33ukddtat","2021-09-09 13:05:46","login"),
(5,100,"3ojsfktk6h2okbpcq3ao6j7u65","2021-09-09 14:33:40","login"),
(6,100,"3ojsfktk6h2okbpcq3ao6j7u65","2021-09-09 14:42:37","logout"),
(7,122,"apcct1h6hdiufiedh08r56j73a","2021-09-10 12:21:52","login"),
(8,122,"apcct1h6hdiufiedh08r56j73a","2021-09-10 12:33:15","login"),
(9,122,"65mccgnhpktpt6mjo64rcqtgfi","2021-09-10 12:35:17","login"),
(10,122,"f1vsj55b8eakrl5nar17eg8c06","2021-09-10 12:37:47","login"),
(11,122,"6u2n77j73rva8klba4djkcjogg","2021-09-10 12:40:20","login"),
(12,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 12:50:35","login"),
(13,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 12:59:18","login"),
(14,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 13:04:24","login"),
(15,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 13:08:23","login"),
(16,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 13:22:23","login"),
(17,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 13:54:19","login"),
(18,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 13:55:25","login"),
(19,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 13:56:30","login"),
(20,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 13:57:53","login"),
(21,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 14:00:18","login"),
(22,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 14:01:40","login"),
(23,122,"rtsu8dsjja5qkafua2oesgr043","2021-09-10 14:38:10","login");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `idusers` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `creationdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `idusertype` int(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idstaff` int(200) NOT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=123 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` VALUES (100,"admin","admin","2021-02-15 11:27:09",1,"active",1,1),
(122,"PCTW3270","english14","2021-09-09 14:36:58",2,"active",2,6);


DROP TABLE IF EXISTS `usershistory`;

CREATE TABLE `usershistory` (
  `idusershistory` int(200) NOT NULL AUTO_INCREMENT,
  `idusers` int(200) NOT NULL,
  `activation` date NOT NULL,
  `deactivation` date NOT NULL,
  `lastlogin` date NOT NULL,
  PRIMARY KEY (`idusershistory`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usershistory` VALUES (1,2,"2021-02-15","0000-00-00","2021-02-15");


DROP TABLE IF EXISTS `usertypes`;

CREATE TABLE `usertypes` (
  `idusertypes` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idusertypes`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usertypes` VALUES (1,"Admin"),
(2,"Incharge"),
(3,"Deo");


SET foreign_key_checks = 1;
