CREATE DATABASE IF NOT EXISTS `school_ctpfsd`;

USE `school_ctpfsd`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `admissions`;

CREATE TABLE `admissions` (
  `idadmission` int(200) NOT NULL AUTO_INCREMENT,
  `idstudent` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `totalfee` int(200) NOT NULL,
  `paidfee` int(200) NOT NULL,
  `pendingdues` int(200) NOT NULL,
  `admissiondate` date NOT NULL DEFAULT current_timestamp(),
  `discount` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `registration` varchar(200) NOT NULL,
  `idstaff` varchar(200) NOT NULL,
  PRIMARY KEY (`idadmission`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admissions` VALUES (1,9,0,"2021-02-18","2021-02-18",1500,1500,0,"2021-02-18",0,0,0,"2021CTPF",1),
(2,10,0,"2021-02-18","2021-02-18",1500,1500,0,"2021-02-18",0,0,1,"20211CTPF",1),
(3,11,0,"2021-02-18","2021-02-18",1500,1500,0,"2021-02-18",0,0,1,"20211CTPF",1),
(4,12,2,"2021-02-18","2021-02-18",4200,2100,0,"2021-02-18",2100,1000,1,"20211CTPF",1),
(6,14,2,"2021-02-22","2021-02-22",3200,1600,0,"2021-02-22",1600,0,1,"2021CTPF1",1),
(7,15,2,"2021-02-22","2021-02-22",3200,3200,0,"2021-02-22",0,0,3,"2021CTPF1",1),
(8,16,2,"2021-02-22","2021-02-22",3200,3200,0,"2021-02-22",0,0,1,"2021CTPF1",1),
(9,17,2,"2021-02-22","2021-02-22",4200,0,0,"2021-02-22",4200,1000,1,"2021CTPF1",1),
(10,18,2,"2021-02-23","2021-02-23",4200,0,0,"2021-01-23",4200,1000,1,"2021CTPF1",1),
(11,19,3,"2021-03-02","2021-03-02",7400,5000,2400,"2021-03-02",0,1000,1,"2021CTPF1",1),
(12,20,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(13,21,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(14,22,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(15,23,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(16,24,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(17,25,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(18,26,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(19,27,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(20,28,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(21,29,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(22,30,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(23,31,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(24,32,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(25,33,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(26,34,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(27,35,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(28,36,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(29,37,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(30,38,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(31,39,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(32,40,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(33,41,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(34,42,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(35,43,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(36,44,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(37,45,1,"2021-03-02","2021-03-02",0,0,0,"2021-03-02",0,0,1,"2021CTPF1",1),
(38,46,1,"2021-03-02","2021-03-02",0,0,0,"2021-03-02",0,0,1,"2021CTPF1",1),
(39,47,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(40,48,1,"2021-03-02","2021-03-02",2600,2600,0,"2021-03-02",0,1000,1,"2021CTPF1",1),
(41,49,1,"2021-03-03","2021-03-03",0,0,0,"2021-03-03",0,0,1,"2021CTPF1",1),
(42,50,1,"2021-03-03","2021-03-03",0,0,0,"2021-03-03",0,0,1,"2021CTPF1",1),
(43,51,1,"2021-03-08","2021-03-08",2600,2600,0,"2021-03-08",0,1000,3,"2021CTPF3",3);


DROP TABLE IF EXISTS `courses`;

CREATE TABLE `courses` (
  `idcourses` int(200) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(200) NOT NULL,
  `fee` int(200) NOT NULL,
  PRIMARY KEY (`idcourses`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `courses` VALUES (1,"Bike2Weeks",1600),
(2,"Car2Weeks",3200),
(3,"Car4Weeks",6400);


DROP TABLE IF EXISTS `expense`;

CREATE TABLE `expense` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `idexpenses` int(200) NOT NULL AUTO_INCREMENT,
  `idexpensetype` int(200) NOT NULL,
  `amount` int(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `idschools` int(200) NOT NULL,
  `idusers` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idexpenses`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO `expenses` VALUES (1,1,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(2,2,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(3,3,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(4,4,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(5,5,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(6,6,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(7,1,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(8,2,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(9,3,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(10,4,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(11,5,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(12,6,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26");


DROP TABLE IF EXISTS `expensetypes`;

CREATE TABLE `expensetypes` (
  `idexpensetypes` int(200) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`idexpensetypes`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `expensetypes` VALUES (1,"Petrol"),
(2,"Maintenance"),
(3,"Salary"),
(4,"Rent"),
(5,"Miscellaneous"),
(6,"Welfare");


DROP TABLE IF EXISTS `income`;

CREATE TABLE `income` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `schools`;

CREATE TABLE `schools` (
  `idschools` int(200) NOT NULL AUTO_INCREMENT,
  `incharge` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `schoolcode` varchar(200) NOT NULL,
  PRIMARY KEY (`idschools`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `schools` VALUES (1,"Ali Nizami","GM Abad","FSD","GMABD"),
(2,"Sajid Habib","People Colony","FSD","PC"),
(3,"Sajid Habib","Samundri","FSD","SMND"),
(4,"Sajid Habib","Jaranwala","FSD","JRNW");


DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `idstaff` int(200) NOT NULL AUTO_INCREMENT,
  `idschool` int(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `belt` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `idtypestaff` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idstaff`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `staff` VALUES (1,1,"Ali","Nizami","DEO",9,03216611821,1,"2021-02-18"),
(2,2,"Ali","Kamran","TW",99,03363332006,2,"2021-03-03"),
(3,3,"Sajid","Habib","STW",6,03000445571,10,"2021-03-03"),
(4,1,"Riaz","Anjum","TW",323,03005124363,3,"2021-03-04"),
(5,1,"Asif Sattar","Anjum","TW",323,03006370900,3,"2021-03-04");


DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `idstudents` int(200) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) NOT NULL,
  `fathername` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `cnic` varchar(200) NOT NULL,
  `address` varchar(300) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` time NOT NULL,
  `blood` varchar(200) NOT NULL,
  `idadmission` int(200) NOT NULL,
  PRIMARY KEY (`idstudents`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4;

INSERT INTO `students` VALUES (1,"Ali","Nizami","nizami@email.com","male","0000-00-00",2147483647,"aklfdklajf",2147483647,0,1,1,"0000-00-00","0000-00-00","00:00:00","A+",0),
(2,"Ali","Nizami","nizami@email.com","male","1991-05-05",2147483647,"aklfdklajf",2147483647,0,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(3,"Ali","Nizami","nizami@email.com","male","1991-05-05",2147483647,"aklfdklajf",2147483647,0,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(4,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(5,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(6,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(7,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(8,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(9,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(10,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(11,"Ali","Nizami","nizami@email.com","male","1991-05-05",3310221557297,"aklfdklajf",3216611821,1,1,0,"0000-00-00","0000-00-00","00:00:00","A+",0),
(12,"Aliya","Ali","ali@email.com","female","1991-05-05",3310221557299,"abc",3216611821,"yes",1,0,"0000-00-00","0000-00-00","00:00:00","A+",4),
(14,"Ali Nizami","Saleem","ali@email.com","male","1990-08-04",3310221557297,"abc",3216611821,"no",1,2,"0000-00-00","0000-00-00","00:00:00","A+",6),
(15,"Ali Nizami","Saleem","ali@email.com","male","1990-08-04",3310221557297,"abc",3216611821,"no",1,2,"0000-00-00","0000-00-00","00:00:00","A+",7),
(16,"Ali Nizami","Saleem","ali@email.com","male","1990-08-04",3310221557297,"abc",3216611821,"no",1,2,"0000-00-00","0000-00-00","00:00:00","A+",8),
(17,"Ali nizami","saleem","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,2,"0000-00-00","0000-00-00","00:00:00","A+",9),
(18,"Ali nizami","saleem","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,2,"0000-00-00","0000-00-00","00:00:00","A+",10),
(19,"Ali","Saleem","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,3,"0000-00-00","0000-00-00","00:00:00","A+",11),
(20,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",12),
(21,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",13),
(22,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",14),
(23,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",0),
(24,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",16),
(25,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",17),
(26,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",18),
(27,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",19),
(28,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",20),
(29,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",21),
(30,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",22),
(31,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",23),
(32,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",24),
(33,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",25),
(34,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",26),
(35,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",27),
(36,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",28),
(37,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",29),
(38,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",30),
(39,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",31),
(40,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",32),
(41,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",33),
(42,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",34),
(43,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",35),
(44,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"abc",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",36),
(45,"","","","male","0000-00-00","","","",0,1,1,"0000-00-00","0000-00-00","00:00:00","A+",37),
(46,"","","","male","0000-00-00","","","",0,1,1,"0000-00-00","0000-00-00","00:00:00","A+",38),
(47,"Ali","Nizami","ali@nizami.com","male","1990-08-04",3310221557597,"abc house",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",39),
(48,"Ali","Nizami","ali@nizami.com","male","1990-08-04",3310221557597,"abc house",3216611821,1000,1,1,"0000-00-00","0000-00-00","00:00:00","A+",40),
(49,"","","","male","0000-00-00","","","",0,1,1,"0000-00-00","0000-00-00","00:00:00","A+",41),
(50,"","","","male","0000-00-00","","",666666666666666666666666666666666666666,0,1,1,"0000-00-00","0000-00-00","00:00:00","A+",42),
(51,"Asif","Sattar","ali@email.com","male","0000-00-00",3211121557297,"abc",03216611821,1000,3,1,"0000-00-00","0000-00-00","00:00:00","A+",43),
(52,"Asif","Sattar","ali@email.com","male","0000-00-00",3211121557297,"abc",03216611821,1000,3,1,"0000-00-00","0000-00-00","00:00:00","A+",44),
(53,"Asif","Sattar","ali@email.com","male","0000-00-00",3211121557297,"abc",03216611821,1000,3,1,"0000-00-00","0000-00-00","00:00:00","A+",45),
(54,"Asif","Sattar","ali@email.com","male","0000-00-00",3211121557297,"abc",03216611821,1000,3,1,"0000-00-00","0000-00-00","00:00:00","A+",46),
(55,"Asif","Sattar","ali@email.com","male","0000-00-00",3211121557297,"abc",03216611821,1000,3,1,"0000-00-00","0000-00-00","00:00:00","A+",47);


DROP TABLE IF EXISTS `typestaff`;

CREATE TABLE `typestaff` (
  `idtypestaff` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idtypestaff`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `typestaff` VALUES (1,"ADMIN"),
(2,"Data Entry Operator"),
(3,"Mali"),
(4,"Naib Qasid"),
(5,"Instructor"),
(6,"Instructor PVT"),
(7,"Lady Instructor"),
(8,"Lady Instructor PVT"),
(9,"Machanic"),
(10,"Incharge");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `idusers` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `creationdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `idusertype` int(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idstaff` int(200) NOT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` VALUES (2,"admin","admin","2021-02-15 11:27:09",1,"active",1,1),
(6,"ali","ali","2021-03-04 12:32:18",2,"active",3,3);


DROP TABLE IF EXISTS `usershistory`;

CREATE TABLE `usershistory` (
  `idusershistory` int(200) NOT NULL AUTO_INCREMENT,
  `idusers` int(200) NOT NULL,
  `activation` date NOT NULL,
  `deactivation` date NOT NULL,
  `lastlogin` date NOT NULL,
  PRIMARY KEY (`idusershistory`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usershistory` VALUES (1,2,"2021-02-15","0000-00-00","2021-02-15");


DROP TABLE IF EXISTS `usertypes`;

CREATE TABLE `usertypes` (
  `idusertypes` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idusertypes`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usertypes` VALUES (1,"Admin"),
(2,"Incharge"),
(3,"Deo");


SET foreign_key_checks = 1;
