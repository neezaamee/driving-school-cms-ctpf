CREATE DATABASE IF NOT EXISTS `school_ctpfsd`;

USE `school_ctpfsd`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `admissions`;

CREATE TABLE `admissions` (
  `idadmission` int(200) NOT NULL AUTO_INCREMENT,
  `idstudent` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `totalfee` int(200) NOT NULL,
  `paidfee` int(200) NOT NULL,
  `pendingdues` int(200) NOT NULL,
  `admissiondate` datetime NOT NULL DEFAULT current_timestamp(),
  `discount` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `registration` varchar(200) NOT NULL,
  `admissionbyuserid` int(20) NOT NULL,
  PRIMARY KEY (`idadmission`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admissions` VALUES (54,63,1,"2021-06-12","2021-06-12","",2600,2600,0,"2021-06-12 00:00:00",0,1000,2,"2021CTPF21",0),
(55,64,1,"2021-06-12","2021-06-12","",2600,2600,0,"2021-06-12 00:00:00",0,1000,2,"2021CTPF31",0),
(56,65,1,"2021-06-16","2021-06-16","",1600,1600,0,"2021-06-16 00:00:00",0,0,5,"2021CTPF51",0),
(57,66,1,"2021-06-16","2021-06-16","",1600,1600,0,"2021-06-16 00:00:00",0,0,5,"2021CTPF52",111);


DROP TABLE IF EXISTS `courses`;

CREATE TABLE `courses` (
  `idcourses` int(200) NOT NULL AUTO_INCREMENT,
  `coursename` varchar(200) NOT NULL,
  `fee` int(200) NOT NULL,
  PRIMARY KEY (`idcourses`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `courses` VALUES (1,"Bike2Weeks",1600),
(2,"Car2Weeks",3200),
(3,"Car4Weeks",6400);


DROP TABLE IF EXISTS `expense`;

CREATE TABLE `expense` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `expenses`;

CREATE TABLE `expenses` (
  `idexpenses` int(200) NOT NULL AUTO_INCREMENT,
  `idexpensetype` int(200) NOT NULL,
  `amount` int(200) NOT NULL,
  `description` varchar(500) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idusers` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idexpenses`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;

INSERT INTO `expenses` VALUES (1,1,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(2,2,200,"Car number VXL-2020 mein petrol dilwaya",2,3,"2021-06-26"),
(3,3,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(4,4,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(5,5,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(6,6,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(7,1,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(8,2,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(9,3,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-06-20"),
(10,4,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26"),
(11,5,200,"Vehicle No ABC mein 200 ka petrol dilwaya",0,2,"2021-02-20"),
(12,6,200,"Car number VXL-2020 mein petrol dilwaya",0,2,"2021-02-26");


DROP TABLE IF EXISTS `expensetypes`;

CREATE TABLE `expensetypes` (
  `idexpensetypes` int(200) NOT NULL AUTO_INCREMENT,
  `type` varchar(200) NOT NULL,
  PRIMARY KEY (`idexpensetypes`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `expensetypes` VALUES (1,"Petrol"),
(2,"Maintenance"),
(3,"Salary"),
(4,"Rent"),
(5,"Miscellaneous"),
(6,"Welfare");


DROP TABLE IF EXISTS `income`;

CREATE TABLE `income` (
  `idincome` int(200) NOT NULL,
  `year` date NOT NULL,
  `january` int(200) NOT NULL,
  `february` int(200) NOT NULL,
  `march` int(200) NOT NULL,
  `april` int(200) NOT NULL,
  `may` int(200) NOT NULL,
  `june` int(200) NOT NULL,
  `july` int(200) NOT NULL,
  `augast` int(200) NOT NULL,
  `september` int(200) NOT NULL,
  `november` int(200) NOT NULL,
  `december` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `schools`;

CREATE TABLE `schools` (
  `idschools` int(200) NOT NULL AUTO_INCREMENT,
  `incharge` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  `schoolcode` varchar(200) NOT NULL,
  PRIMARY KEY (`idschools`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `schools` VALUES (1,"Ali Nizami","CTPF","FSD","CTPF"),
(2,"Sajid Habib","People Colony","FSD","PC"),
(3,"Sajid Habib","Samundri","FSD","SMND"),
(4,"Sajid Habib","Jaranwala","FSD","JRNW"),
(5,"Asif Sattar","Dijkot","FSD","DJKT"),
(6,"Riaz Anjum","Jhumra","FSD","JMRA"),
(10,"Ali Nizami","GM Abad","FSD","GMABD");


DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `idstaff` int(200) NOT NULL AUTO_INCREMENT,
  `idschool` int(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `belt` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `idtypestaff` int(200) NOT NULL,
  `date` date NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`idstaff`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `staff` VALUES (1,1,"Ali","Nizami","DEO",9,3216611821,1,"2021-02-18"),
(2,2,"Imran","Qazi","TWF",451,3363332006,10,"2021-03-03"),
(3,3,"Sajid","Habib","STW",6,3000445571,10,"2021-03-03"),
(11,5,"Nadeem ul Hassan","","TW",451,"",10,"2021-06-16");


DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `idstudents` int(200) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) NOT NULL,
  `fathername` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `cnic` varchar(200) NOT NULL,
  `address` varchar(300) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` varchar(200) NOT NULL,
  `blood` varchar(200) NOT NULL,
  `idadmission` int(200) NOT NULL,
  PRIMARY KEY (`idstudents`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4;

INSERT INTO `students` VALUES (63,"Ali","Nizami","nizami@email.com","male","1990-08-04",3310221557297,"Nishatabad Faisalabad",03216611821,1000,2,1,"0000-00-00","0000-00-00","morning","A+",54),
(64,"Asif","Sattar","asif@email.com","male","0000-00-00",3310221557297,"Shorkot",03006370900,1000,2,1,"0000-00-00","0000-00-00","morning","A+",55),
(65,"Babar","Rasool","babar@email.com","male","1983-04-05",3310221557297,"abc",03216611821,0,5,1,"0000-00-00","0000-00-00","morning","A+",56),
(66,"Kashif","Munir","kashif@email.com","male","1981-01-01",3310221557297,"zyx",03216611121,0,5,1,"0000-00-00","0000-00-00","morning","A+",57);


DROP TABLE IF EXISTS `typestaff`;

CREATE TABLE `typestaff` (
  `idtypestaff` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idtypestaff`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `typestaff` VALUES (1,"ADMIN"),
(2,"Data Entry Operator"),
(3,"Mali"),
(4,"Naib Qasid"),
(5,"Instructor"),
(6,"Instructor PVT"),
(7,"Lady Instructor"),
(8,"Lady Instructor PVT"),
(9,"Machanic"),
(10,"Incharge");


DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `idusers` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `creationdate` timestamp NOT NULL DEFAULT current_timestamp(),
  `idusertype` int(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idstaff` int(200) NOT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` VALUES (2,"samundri",123,"2021-03-04 12:32:18",2,"active",3,3),
(100,"admin","admin","2021-02-15 11:27:09",1,"active",1,1),
(109,"PS",123,"2021-04-07 14:33:23",3,"active",2,2),
(111,"DJKTTW451","oDQaibs","2021-06-16 11:53:10",2,"active",5,11);


DROP TABLE IF EXISTS `usershistory`;

CREATE TABLE `usershistory` (
  `idusershistory` int(200) NOT NULL AUTO_INCREMENT,
  `idusers` int(200) NOT NULL,
  `activation` date NOT NULL,
  `deactivation` date NOT NULL,
  `lastlogin` date NOT NULL,
  PRIMARY KEY (`idusershistory`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usershistory` VALUES (1,2,"2021-02-15","0000-00-00","2021-02-15");


DROP TABLE IF EXISTS `usertypes`;

CREATE TABLE `usertypes` (
  `idusertypes` int(200) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  PRIMARY KEY (`idusertypes`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `usertypes` VALUES (1,"Admin"),
(2,"Incharge"),
(3,"Deo");


SET foreign_key_checks = 1;
