CREATE DATABASE IF NOT EXISTS `school_ctpfsd`;

USE `school_ctpfsd`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `admissions`;

CREATE TABLE `admissions` (
  `idadmission` int(200) NOT NULL AUTO_INCREMENT,
  `idstudent` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `totalfee` int(200) NOT NULL,
  `paidfee` int(200) NOT NULL,
  `admissiondate` date NOT NULL,
  `discount` varchar(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `registration` varchar(200) NOT NULL,
  `idinstructor` varchar(200) NOT NULL,
  PRIMARY KEY (`idadmission`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `courses`;

CREATE TABLE `courses` (
  `idcourse` int(200) NOT NULL AUTO_INCREMENT,
  `category` varchar(200) NOT NULL,
  `duration` varchar(200) NOT NULL,
  `fee` int(200) NOT NULL,
  PRIMARY KEY (`idcourse`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `schools`;

CREATE TABLE `schools` (
  `idschool` int(200) NOT NULL AUTO_INCREMENT,
  `incharge` varchar(200) NOT NULL,
  `location` varchar(200) NOT NULL,
  `city` varchar(200) NOT NULL,
  PRIMARY KEY (`idschool`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `idstaff` int(200) NOT NULL AUTO_INCREMENT,
  `idschool` int(200) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `belt` varchar(200) NOT NULL,
  `designation` varchar(200) NOT NULL,
  PRIMARY KEY (`idstaff`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `students`;

CREATE TABLE `students` (
  `idstudents` int(200) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(200) NOT NULL,
  `fathername` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `dob` date NOT NULL,
  `cnic` int(200) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone` int(200) NOT NULL,
  `pickndrop` varchar(200) NOT NULL,
  `idschool` int(200) NOT NULL,
  `idcourse` int(200) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `time` time NOT NULL,
  PRIMARY KEY (`idstudents`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `idusers` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `lastname` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `rank` varchar(200) NOT NULL,
  `belt` varchar(200) NOT NULL,
  `creationdate` date NOT NULL DEFAULT current_timestamp(),
  `role` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL,
  `history` varchar(200) NOT NULL,
  PRIMARY KEY (`idusers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



SET foreign_key_checks = 1;
